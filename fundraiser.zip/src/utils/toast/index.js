import errorToast from './error'
import successToast from './sucess';

export { successToast, errorToast };
