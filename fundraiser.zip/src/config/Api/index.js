// export const BASE_URL = "https://api.loginlegacy.com/api/v1/";
// export const BASE_URL = "https://api.loginlegacy.com/api/v1/";
export const BASE_URL = "https://api.cigarsforcharity.com/api/v1/";
// export const BASE_URL = "http://localhost:3009/api/v1/";


export const ADMIN_BASE_URL = "https://api.cigarsforcharity.com/admin/api/v1/";
// export const ADMIN_BASE_URL = "http://localhost:3009/admin/api/v1/";



// export const BASE_URL =
//   'http://ec2-13-233-89-35.ap-south-1.compute.amazonaws.com/';
// https://cigarsforcharity.com/api/v1/auth/verify-otp