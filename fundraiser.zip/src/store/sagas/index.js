import { all } from "redux-saga/effects";

import {
  verifyOtpSaga,
  signupUserSaga,
  getUserSaga,
  updateUserSaga,
  saveUserEmailSaga,
  saveUserDetailSaga,
  updateUserDetailSaga
} from "./user";


import {
  saveFundDetailsSaga,
  getFundDetailsSaga,
  getFundDetailByIDSaga
} from './event';

export default function* rootSaga() {
  yield all([
    verifyOtpSaga(),
    signupUserSaga(),
    getUserSaga(),
    updateUserSaga(),
    saveUserEmailSaga(),
    saveUserDetailSaga(),
    saveFundDetailsSaga(),
    getFundDetailsSaga(),
    getFundDetailByIDSaga(),
    updateUserDetailSaga()
  ]);
}
