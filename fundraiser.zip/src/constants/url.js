const BASE_URL = "http://localhost:3009/";

const url = {
    _login: BASE_URL + "auth/login",
   };

export default url;
